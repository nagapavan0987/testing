<?php
session_start();
if($_SESSION['uname']=="")
{
	header("location:index.php");
}

include 'db.php';?>
<!DOCTYPE html>
<html>
<head>
	<title>Welcome to Faculty Management</title>
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body style="background:#cce6ff;">
	<div class="container-fluid"  style="background: lightgrey; height: auto;">

		<?php include 'includes/login_set.php'; ?>
		
	</div>
	<div class="container-fluid">
		<div class="col-sm-3 warpper">
			<a href="dashboard.php" style="text-decoration: none; color: black;"><p>Dashboard</p></a>
			<a href="enquiry.php" style="text-decoration: none; color: black;"><p>Enquiry</p></a>
			<a href="title.php" style="text-decoration: none; color: black;"><p>Title Content</p></a>
			<a href="about.php" style="text-decoration: none; color: black;"><p>About Us</p></a>
			<a href="Online-Appiled.php" style="text-decoration: none; color: black;"><p>Online Applied</p></a>
			<a href="district.php" style="text-decoration: none; color: black;"><p>District Management</p></a>
			<a href="digital.php" style="text-decoration: none; color: black;"><p>Digital Marketing</p></a>
			<a href="Faculty-Management.php" style="text-decoration: none; color: black;"><p>Faculty Management</p></a>
			<a href="adminregistration.php" style="text-decoration: none; color: black;"><p>New Admin Registration</p></a>
		</div>
		<div class="col-sm-1"></div>
		<div class="col-sm-5">
			<br><br>
			<form method="post" enctype="multipart/form-data">
				<div class="form-group">
					<p style="font-size: 20px;">Faculty Name</p>
					<input type="text" name="user" class="form-control" placeholder="Enter Faculty Name" required="">
				</div>
				<div class="form-group">
					<p style="font-size: 20px;">Faculty Designation</p>
					<input type="text" name="desg" class="form-control" placeholder="Enter Faculty Designation" required="">
				</div>
				<div class="form-group">
					<p style="font-size: 20px;">Faculty Description</p>
					<textarea name="desc" class="form-control" placeholder="Enter Faculty Name" required=""></textarea>
				</div>
				<div class="form-group">
					<p style="font-size: 20px;">Image Upload</p>
					<input type="file" name="pic" class="form-control" required="">
				</div>
				<p style="text-align: center;"><input type="submit" name="submit" value="Add Faculty" class="btn btn-success"></p>
			</form>
			
		</div>
		<div class="col-sm-2"></div>
	</div>







<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
</body>
</html>



<?php
if(isset($_POST['submit'])){
	$uid=uniqid();
	$name=$_POST['user'];
	$desg=$_POST['desg'];
	$desc=$_POST['desc'];
	$a=$_FILES['pic']['name'];
	$b=$_FILES['pic']['tmp_name'];
	$target="images/";
	move_uploaded_file($b,$target.$a);
	$inst="insert into faculty(uid,Name,Designation,Description,Images) values('$uid','$name','$desg','$desc','$a')";
	$trigger=mysqli_query($conn,$inst);
	if($trigger){
		echo "Added Successfully";
	}else{
		echo "Something Wrong";
	}
}
?>