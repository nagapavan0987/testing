<?php
$conn=mysqli_connect("localhost","root","","testing") or die("Somthing Is Wrong With DB");


?>